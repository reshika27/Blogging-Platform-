# Blog-App-API-with-Node-Express-and-MongoDB
Using Node.js, Express, and MongoDB to create a RESTful API for a blog application. Authentication, creation, reading, editing, and deletion of blog entries and commenting on blog postings will all be possible with this API. 


Run the above Project:
-- Clone the project or download zip file.
-- Make changes related to your MongoDB database.
-- Enter command - **npm start**
-- Go to Postman to check APIs.
